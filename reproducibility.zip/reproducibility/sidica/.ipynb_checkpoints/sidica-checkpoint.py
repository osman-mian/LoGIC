import numpy as np
from node import Node
from mdl_oracle import MDLOracle
from mdl_score import MDLScore
class SIDICA:
    
    def __init__(self,orc=None,sc=None):
        self.is_init = True
        self.oracle = orc if orc is not None else MDLOracle()
        self.score  = sc  if sc  is not None else MDLScore()

    def learn(self,data):
        dims  = data.shape[1]
        rows  = data.shape[0]
        graph = np.eye(dims)*0
        
        c_order = self.determineOrder(data)
        for target in range(1,dims):
            poss_parents            = [c_order[i] for i in range(target)]            #get all variables in causal ordering upto this variable
            parents , scm           = self.find_parents(target,poss_parents,data)    #try and do subset selection for this variable given variables before it, return SCM
            graph[parents , target] = 1
            
            data[:,target]          = self.imputeMissing(target,parents,data,scm)    #use the learned parents and SCM to impute missing values for this target
          
        return data, graph
    
    
    def determineOrder(self,data):
        dims = data.shape[1]
        
        node_array=[]
        for i in range(dims):
            node_array.append(Node(i,dims))
        
        
        for i in range(dims):
            for j in range(i+1,dims):
                delta_ij,delta_ji = self.oracle(i,j,data)
                node_array[i].comps[j] = delta_ij
                node_array[j].comps[i] = delta_ji
                
                
        orig = [n.id for n in node_array]
        node_array.sort()
        mod  = [n.id for n in node_array]
        
        return mod