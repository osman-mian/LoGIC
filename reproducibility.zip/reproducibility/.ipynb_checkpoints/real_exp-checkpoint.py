if __name__ == "__main__":

    import sys
    import os
    import gc

    import networkx as nx

    from utils import *
    from experiment_factory import ExperimentFactory
    from acyclic_graph_generator import AcyclicGraphGenerator
    from experiment_handler import Experiment
    from mnar_sampler import mnar_mask

    np.random.seed(37)
    from methods import LOGICX,MEANX,MICEX,GAINX,MIRACLEX,MFX
    from datetime import datetime 

    def realworld_data(fname,gname):
        data            = standardize(load_data(fname))
        graph           = load_graph(gname)
        return fname,data,graph


    def main():
        rcount          = 1000 if len(sys.argv)<2 else int(sys.argv[1])        
        mask_probs,exp_fname = ExperimentFactory.real_setup(rcount)
        mar_type  = 0
        mnar_type = 1
        miss_type = [mar_type,mnar_type]
        dfiles = [ "./data/realworld/reged5a.txt"      , "./data/realworld/reged4.txt"]
        gtruth = [ "./data/realworld/reged5a_truth.txt", "./data/realworld/reged4_truth.txt"]
        tot_experiments = len(mask_probs) * len(dfiles) * len(miss_type)
        exp_counter     = 0
        subsamples      = 10000
        exp_fname       = exp_fname.replace(".pkl", f"_{subsamples}.pkl")

        exp_headers     = ['fname','tot','samples','mnar','oracle','prob','shd','sid','paid','tp','fp','fn','rmse','ir','predicted','graph']#,'miss_data','fill_data']
        experiment      = Experiment(exp_headers,exp_fname,preload=False)
        methods         = [LOGICX(),LOGICX(False),MIRACLEX(),GAINX(),MFX(),MICEX(),MEANX()]

        print("Saving to ",exp_fname)
        for i in range(len(dfiles)):
            fname   = dfiles[i]
            gname   = gtruth[i]
            fname,dt,graph  = realworld_data(fname,gname)
            dt = dt[0:subsamples,:]
            print("Loaded ",fname,": ",dt.shape)
            print("Truth ",gname,": ",graph.shape)
            ugraph = np.array(np.abs(graph) + np.abs(graph).T,dtype=bool)
            rcount = dt.shape[0]
            for mt in miss_type:
                for p in mask_probs:
                    exp_counter+=1
                    #if exp_counter <14:continue

                    if   mt == mar_type:
                        mask = binary_sampler(1 - p, dt.shape[0], dt.shape[1])
                    elif mt ==mnar_type:
                        mask = mnar_mask(dt,p)
                    xmis            = dt.copy()
                    xmis[mask == 0] = np.nan
                    mrows_ids       = np.sum(mask,axis=1)<dt.shape[1]

                    for alg in methods:
                        try:
                            midata,pred,cpdag     = alg.timed_run(np.copy(xmis),mrows_ids,graph)
                            rmse,ir               = rmse_loss(dt,midata,mask)
                            shd,sid,paid,tp,fp,fn = calc_ud_stats(pred,graph,cpdag)
                            exp_res               = [fname,np.sum(graph),rcount,mt,alg.name_,p,shd,sid,paid,tp,fp,fn,rmse,ir,pred,graph]#,np.copy(xmis),midata]
                            ts                    = datetime.now().strftime("%d:%m:%y:%H:%M")

                            experiment.add(exp_res)
                            experiment.save_state()
                            gc.collect()  

                            print("[",ts,"] ",rcount,",",exp_counter,"/",tot_experiments,", ",fname,", Method: ",alg.name_," , prob: ",p," MNAR: ",mt,", Tot: ",np.sum(graph),", SHD: ",shd,", SID: ",sid,", PAID: ",paid,", TP: ",tp,", FP: ",fp,", FN: ",fn,", RMSE: ",rmse," IR: ",ir)

                        except Exception as e:
                            ts                    = datetime.now().strftime("%d:%m:%y:%H:%M")
                            print("[",ts,"] ",rcount,",",exp_counter,"/",tot_experiments,", ",fname," for",alg.name_," failed with reason: ",e)
                            gc.collect() 

                    print('---')
        print("#############")


    main();