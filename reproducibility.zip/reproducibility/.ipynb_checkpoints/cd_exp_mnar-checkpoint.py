if __name__ == "__main__":

    import sys
    import os
    import gc

    from utils import *
    from experiment_factory import ExperimentFactory
    import networkx as nx
    from acyclic_graph_generator import AcyclicGraphGenerator
    from experiment_handler import Experiment
    from mnar_sampler import mnar_mask

    np.random.seed(37)
    from methods import LOGICX,MEANX,MICEX,GAINX,MIRACLEX,MFX,MVPCX, MISSDAGX

    from datetime import datetime

    def gen_data(nodes=10,mech='gaussian_add',noise=0.4,idx=0,rcount=1000,pre_load=False,viz=False):
        foldname = './data/'+str(rcount)+'/'+mech+'/'+str(nodes)+"_"+str(noise)+"/"
        fname = foldname + 'exp' + str(idx) + '.txt'
        gname = foldname + 'exp' + str(idx) + '_truth.txt'
        vname = './viz/'+mech+'/'+str(nodes)+"_"+str(noise)+"/"+ 'exp' + str(idx) + '/'

        if pre_load:
            data            = load_data(fname)
            graph           = load_graph(gname)
            return fname,data,graph


        ed = np.max([1,np.floor(np.log2(nodes))-1])
        #print("exp: ",ed)
        generator = AcyclicGraphGenerator(mech, npoints=rcount,nodes=nodes,initial_variable_generator=gaussian_cause,noise_coeff=noise,expected_degree=ed, dag_type='erdos')
        dt, G = generator.generate()
        graph = nx.to_numpy_array(G)
        data  = dt.to_numpy().reshape((-1,nodes))
        dims  = graph.shape[1]
        data = standardize(data)

        if not os.path.exists(foldname): os.makedirs(foldname) 
        np.savetxt(fname,  data, delimiter=",")
        np.savetxt(gname, graph, delimiter=",")

        if False and viz:
            if not os.path.exists(vname): os.makedirs(vname) 

            for i in range(dims):
                    for j in range(dims):
                        if graph[i,j]!=0: 
                            print(i," -> ", j)
                        save_fig(data[:,i],data[:,j],vname+str(i)+'_'+str(j)+'.png',)

        return fname,data,graph

    def main():
        rcount          = 1000 if len(sys.argv)<2 else int(sys.argv[1])
        mechs,noises,nodes,mask_probs,source_only,file_count,exp_fname = ExperimentFactory.cd_mnar_setup(rcount)
        tot_experiments = len(mechs) * len(noises) * len(nodes) * len(mask_probs) * len(source_only) * file_count
        exp_counter     = 0
        exp_headers     = ['fname','tot','so','nodes','samples','oracle','prob','shd','sid','paid','tp','fp','fn','rmse','ir','predicted','graph']#,'miss_data','fill_data']
        experiment      = Experiment(exp_headers,exp_fname,preload=False)

        print("Saving to ",exp_fname)
        methods         = [MISSDAGX()]#MVPCX(),LOGICX(),LOGICX(False)]
        for node in nodes:
            for mech in mechs:
                for noise in noises:
                    for so in source_only:
                        for idx in range(1,file_count+1):
                            fname,dt,graph  = gen_data(node,mech,noise,idx,rcount,pre_load=False)
                            for p in mask_probs:
                                exp_counter+=1
                                #if exp_counter <43:continue

                                mask               = mnar_mask(dt,p)
                                print("Mask size: ",np.sum(1-mask))
                                xmis               = dt.copy()                                             #make a data copy
                                xmis[mask == 0]    = np.nan

                                mrows_ids          = np.sum(mask,axis=1)<dt.shape[1]
                                for alg in methods:
                                    try:
                                        ts                    = datetime.now().strftime("%d.%m.%y:%H:%M")
                                        midata,pred,iscpdag   = alg.run(np.copy(xmis),mrows_ids,graph)
                                        rmse,ir               = -1,-1
                                        shd,sid,paid,tp,fp,fn = calc_ud_stats(pred,graph,iscpdag)
                                        exp_res               = [fname,np.sum(graph),so,node,rcount,alg.name_,p,shd,sid,paid,tp,fp,fn,rmse,ir,pred,graph]
                                        ts                    = datetime.now().strftime("%d:%m:%y:%H:%M")

                                        experiment.add(exp_res)
                                        experiment.save_state()
                                        gc.collect()  

                                        print("[",ts,"] ",rcount,",",exp_counter,"/",tot_experiments,", ",fname,", Method: ",alg.name_,", prob: ",p," source safe: ",so,", Tot: ",np.sum(graph),", SHD: ",shd,", SID: ",sid,", PAID: ",paid,", TP: ",tp,", FP: ",fp,", FN: ",fn,", RMSE: ",rmse," IR: ",ir)
                                    except Exception as e:
                                        ts                    = datetime.now().strftime("%d:%m:%y:%H:%M")
                                        print("[",ts,"] ",rcount,",",exp_counter,"/",tot_experiments,", ",fname," for",alg.name_," failed with reason: ",e)
                                        #print(e)
                                        gc.collect()  

                                print('---')


                            #print(fname," -- SHD: ",shd2,", TP: ",tp,"/",np.sum(graph),", FP: ",fp,", FN: ",fn,", Rev: ",ac)#, "Order: ",c_order)
        print("#############")


    main();