if __name__ == "__main__":

    from utils import *
    import sys
    import os
    import gc
    from datetime import datetime
    from experiment_factory import ExperimentFactory
    import networkx as nx
    from acyclic_graph_generator import AcyclicGraphGenerator
    from experiment_handler import Experiment
    import traceback

    np.random.seed(37)

    from methods import LOGICX,MEANX,MICEX,GAINX,MIRACLEX,MFX

    def gen_data(nodes=10,mech='gaussian_add',noise=0.4,idx=0,rcount=1000,pre_load=False,viz=False):
        foldname = './data/'+str(rcount)+'/'+mech+'/'+str(nodes)+"_"+str(noise)+"/"
        fname = foldname + 'exp' + str(idx) + '.txt'
        gname = foldname + 'exp' + str(idx) + '_truth.txt'
        vname = './viz/'+mech+'/'+str(nodes)+"_"+str(noise)+"/"+ 'exp' + str(idx) + '/'

        if pre_load:
            data            = load_data(fname)
            graph           = load_graph(gname)
            return fname,data,graph


        ed = np.max([1,np.floor(np.log2(nodes))-1])
        #print("exp: ",ed)
        generator = AcyclicGraphGenerator(mech, npoints=rcount,nodes=nodes,initial_variable_generator=gaussian_cause,noise_coeff=noise,expected_degree=ed, dag_type='erdos')
        dt, G = generator.generate()
        graph = nx.to_numpy_array(G)
        data  = dt.to_numpy().reshape((-1,nodes))
        dims  = graph.shape[1]
        data = standardize(data)

        if not os.path.exists(foldname): os.makedirs(foldname) 
        np.savetxt(fname,  data, delimiter=",")
        np.savetxt(gname, graph, delimiter=",")

        if False and viz:
            if not os.path.exists(vname): os.makedirs(vname) 

            for i in range(dims):
                    for j in range(dims):
                        if graph[i,j]!=0: 
                            print(i," -> ", j)
                        save_fig(data[:,i],data[:,j],vname+str(i)+'_'+str(j)+'.png',)

        return fname,data,graph

    def main():
        rcount          = 1000 if len(sys.argv)<2 else int(sys.argv[1])
        mechs,noises,nodes,mask_probs,source_only,file_count,exp_fname = ExperimentFactory.src_setup(rcount)

        tot_experiments = len(mechs) * len(noises) * len(nodes) * len(mask_probs) * len(source_only) * file_count
        exp_counter     = 0

        exp_headers     = ['fname','tot','so','nodes','samples','oracle','prob','auprc','f1','acc']
        experiment      = Experiment(exp_headers,exp_fname,preload=False)

        methods         = [LOGICX(),LOGICX(False)]
        print("Saving to ",exp_fname)
        
        for node in nodes:
            for mech in mechs:
                for noise in noises:
                    for so in source_only:
                        for idx in range(1,file_count+1):
                            fname,dt,graph  = gen_data(node,mech,noise,idx,rcount,pre_load=False)
                            all_vars        = [vv for vv in range(graph.shape[0])]
                            sources         = np.where(np.sum(graph,axis=0)==0)[0]
                            non_source      = list(set(all_vars) - set(sources)) if so else all_vars
                            ns_dt           = dt[:,non_source]
                            for p in mask_probs:
                                exp_counter+=1
                                if exp_counter ==80 or exp_counter==65:continue

                                mask               = np.ones((dt.shape[0],dt.shape[1]))
                                mask[:,non_source] = binary_sampler(1 - p, ns_dt.shape[0], ns_dt.shape[1]) #we will only eliminate non source columns
                                xmis               = dt.copy()                                             #make a data copy
                                xmis[mask == 0]    = np.nan

                                #need the following because MIRACLE crashes otherwise
                                dummy_line         = np.array([np.nan for nn in range(dt.shape[1])])
                                xmis               = np.vstack((xmis,dummy_line)) 

                                dummy_mask         = np.array([0 for nn in range(dt.shape[1])])
                                mask               = np.vstack((mask,dummy_mask)) 
                                #end MIRACLE Adjustment

                                mrows_ids          = np.sum(mask,axis=1)<dt.shape[1]
                                for alg in methods:
                                    try:
                                        ts                    = datetime.now().strftime("%d.%m.%y:%H:%M")
                                        print("[",ts,"] Begin: ",alg.name_)
                                        src                   = np.where(np.sum(graph,axis=0)==0)[0]
                                        src,pred,auprc,f1,acc     = alg.source_run(np.copy(xmis),src,mrows_ids,graph)
                                        exp_res               = [fname,np.sum(graph),so,node,rcount,alg.name_,p,auprc,f1,acc]#,np.copy(xmis),midata]
                                        ts                    = datetime.now().strftime("%d:%m:%y:%H:%M")
                                        print("[",ts,"] ",rcount,",",exp_counter,"/",tot_experiments,", ",fname,", Nodes: ",node,", Method: ",alg.name_,", prob: ",p," source safe: ",so,", Tot: ",np.sum(graph),", True: ",src,", pred: ",pred,", AUPRC: ",auprc,", F1: ",f1,", acc: ",acc)
                                        experiment.add(exp_res)
                                        experiment.save_state()
                                        gc.collect()  
                                    except Exception as e:
                                        ts                    = datetime.now().strftime("%d:%m:%y:%H:%M")
                                        print("[",ts,"] ",rcount,",",exp_counter,"/",tot_experiments,", ",fname," for",alg.name_," failed with reason: ",e)
                                        gc.collect()  

        print("#############")


    main();