import numpy as np
from causallearn.search.ConstraintBased.PC import pc
from causallearn.utils.cit import kci

import concurrent.futures
import multiprocessing as mp
mp.set_start_method('spawn', force=True)

def _timed_run_wrapper(queue, instance, data, mrows=None, tgraph=None):
    try:
        result = instance.run(data, mrows, tgraph)
        queue.put(("ok", result))
    except Exception:
        tb = traceback.format_exc()
        queue.put(("err", tb))
        
class BaseMethod:
    #I wrote the ProcessPoolExecutorCode, ChatGPT converted it to multiprocessing because PPE was not guaranteeing process termination.
    def timed_run(self, data, mrows=None, tgraph=None):

        n, d = data.shape
        timeout_seconds = 60 * 60  # 1 minute per variable
        queue = mp.Queue()
        p = mp.Process(target=_timed_run_wrapper, args=(queue,self, data, mrows, tgraph))
        p.start()

        try:
            status, payload = queue.get(timeout=timeout_seconds)
            p.join()
            if status == "ok":
                return payload
            else:
                raise RuntimeError(f"Exception in subprocess:\n{payload}")
        except Exception as e:
            # Timeout or other queue issues
            if p.is_alive():
                print("Method timeout... killing worker.")
                p.terminate()
                p.join()
                return None
        finally:
            # Ensure resources are cleaned
            p.close()
            queue.close()
            queue.join_thread()

        return None


    def ttimed_run(self,data,mrows=None,tgraph=None):
        n,d   = data.shape        
        #scale allowed computation time with dims
        #5 nodes: 5 minutes
        #10 nodes: 10 minutes
        #15 nodes: 15 minutes

        timeout_seconds = d * 60 #1 minute per variable


        with concurrent.futures.ProcessPoolExecutor(max_workers=1) as executor:
            future = executor.submit(self.run,data,mrows,tgraph)
            try:
                idata = future.result(timeout=timeout_seconds)

                return idata
            except concurrent.futures.TimeoutError:
                print("Method timeout...")
                future.cancel()  # attempt to cancel
                executor.shutdown(wait=False, cancel_futures=True)

                #executor.shutdown(cancel_futures=True)  # kills running processes

                return None

        return None

    def run(self,data,mrows=None,tgraph=None):
        raise NotImplementedError("Run must be implemented using a subclass")



#LOGIC Imports
from logic.logic import LOGIC
from logic.perfect_oracle import PerfectOracle
from logic.mdl_oracle import MDLOracle
from logic.globe_oracle import GLOBEOracle
from logic.poly_oracle import PolyOracle
from logic.mdl_score import MDLScore
from logic.poly_score import PolyScore
from logic.globe_score import GLOBEScore
from sklearn.metrics import f1_score, average_precision_score,accuracy_score

class LOGICX(BaseMethod):
    def __init__(self,oracle=True):
        self.oracle = oracle
        self.name_  = "LOGICG " if not oracle else "LOGICO "
        self.iscpdag = False

    def run(self,data,mrows=None,tgraph=None):
        miss_data,graph = None,None

        indep_oracle    = PerfectOracle(tgraph) if self.oracle is True else GLOBEOracle()
        order_score     = GLOBEScore(cache_result=False)
        alg             = LOGIC(orc=indep_oracle,sc=order_score)
        miss_data,graph = alg.fit_transform(data)

        return miss_data,graph,self.iscpdag
    
    def source_run(self,data,src,mrows=None,tgraph=None):
        miss_data,graph = None,None

        indep_oracle    = PerfectOracle(tgraph) if self.oracle is True else GLOBEOracle()
        order_score     = GLOBEScore(cache_result=False)
        alg             = LOGIC(orc=indep_oracle,sc=order_score)
        pred        = alg.cluster_transform(data)
        
        #import ipdb;ipdb.set_trace()
        dims     = data.shape[1]
        src_bin  = np.zeros(dims)
        pred_bin = np.zeros(dims)
        
        for i in range(len(src)):
            src_bin[src[i]]=1
            
        for i in range(len(pred)):
            pred_bin[pred[i]]=1
            
        auprc = np.round(average_precision_score(src_bin, pred_bin),2)
        f1 = np.round(f1_score(src_bin, pred_bin),2)
        acc = np.round(accuracy_score(src_bin, pred_bin),2)

        return src,pred,auprc,f1,acc

from missdag.dag_methods  import Notears_MLP_MCEM, Notears_MLP_MCEM_INIT
from missdag.miss_methods import miss_dag_nonlinear
from missdag.utils.utils  import postprocess
class MISSDAGX(BaseMethod):
    def __init__(self):
        self.name_ = "MissDag"
        self.iscpdag = False
        self.em_iter = 5
        self.equal_variances = False
        self.graph_thres = 0.1

    def run(self,data,mrows=None,graph=None):
        miss_data,graph = None,None
        tdata = data.astype(np.float32)
        dag_init_method = Notears_MLP_MCEM_INIT()
        dag_method = Notears_MLP_MCEM()
        
        egraph, _, _ = miss_dag_nonlinear(tdata, dag_init_method, dag_method, self.em_iter, self.equal_variances)
        _, graph     = postprocess(egraph, self.graph_thres)
        
        #print(graph)
        #import ipdb;ipdb.set_trace()

        return miss_data,graph,self.iscpdag


#MVPC
from causallearn.utils.cit import mv_fisherz
class MVPCX(BaseMethod):
    def __init__(self):
        self.name_ = "MVPC"
        self.iscpdag = True

    def run(self,data,mrows=None,graph=None):
        miss_data,graph = None,None
        tdata           = data
        graph = pc(tdata, 0.05, mv_fisherz,show_progress=False).G.graph
        dims = graph.shape[1]

        for i in range(dims):
            for j in range(i+1,dims):
                if graph[i,j]==-1 and graph[j,i]==1:
                    graph[i,j]=1
                    graph[j,i]=0
                elif graph[i,j]==1 and graph[j,i]==-1:
                    graph[i,j]=0
                    graph[j,i]=1
                elif graph[i,j]==-1 and graph[j,i]==-1:
                    graph[i,j]=1
                    graph[j,i]=1

        return miss_data,graph,self.iscpdag

    
#MIRACLE
from imps.MIRACLE import MIRACLE
class MIRACLEX(BaseMethod):
    def __init__(self):
        self.name_ = "MIRACLE "
        self.iscpdag = False

    def run(self,data,mrows=None,graph=None):
        miss_data,graph = None,None
        alg             = MIRACLE(num_inputs=data.shape[1],max_steps=400)
        miss_data,graph = alg.fit(data)
        return miss_data,graph,self.iscpdag



from imps.imputation_mean import MeanImputation
class MEANX(BaseMethod):
    def __init__(self):
        self.name_   = "MEAN "
        self.alg     = MeanImputation();
        self.iscpdag = True

    def run(self,data,mrows=None,graph=None):
        miss_data,graph = None,None
        miss_data       = self.alg.fit_transform(data)
        tdata           = miss_data[mrows,:]
        graph = pc(tdata, 0.05, kci, kernelZ='Polynomial',show_progress=False).G.graph

        dims = graph.shape[1]

        for i in range(dims):
            for j in range(i+1,dims):
                if graph[i,j]==-1 and graph[j,i]==1:
                    graph[i,j]=1
                    graph[j,i]=0
                elif graph[i,j]==1 and graph[j,i]==-1:
                    graph[i,j]=0
                    graph[j,i]=1
                elif graph[i,j]==-1 and graph[j,i]==-1:
                    graph[i,j]=1
                    graph[j,i]=1

        return miss_data,graph,self.iscpdag

from imps.imputation_mice import MiceImputation
class MICEX(BaseMethod):
    def __init__(self):
        self.name_ = "MICE "
        self.alg  = MiceImputation();
        self.iscpdag = True

    def run(self,data,mrows=None,graph=None):
        miss_data,graph = None,None
        miss_data       = self.alg.fit_transform(data)
        tdata           = miss_data[mrows,:]
        graph = pc(tdata, 0.05, kci, kernelZ='Polynomial',show_progress=False).G.graph

        dims = graph.shape[1]

        for i in range(dims):
            for j in range(i+1,dims):
                if graph[i,j]==-1 and graph[j,i]==1:
                    graph[i,j]=1
                    graph[j,i]=0
                elif graph[i,j]==1 and graph[j,i]==-1:
                    graph[i,j]=0
                    graph[j,i]=1
                elif graph[i,j]==-1 and graph[j,i]==-1:
                    graph[i,j]=1
                    graph[j,i]=1

        return miss_data,graph,self.iscpdag


from imps.imputation_gain import GainImputation
class GAINX(BaseMethod):
    def __init__(self):
        self.name_ = "GAIN "
        self.alg  = GainImputation();
        self.iscpdag = True

    def run(self,data,mrows=None,graph=None):
        miss_data,graph = None,None
        miss_data       = self.alg.fit_transform(data)
        tdata           = miss_data[mrows,:]
        graph = pc(tdata, 0.05, kci, kernelZ='Polynomial',show_progress=False).G.graph

        dims = graph.shape[1]

        for i in range(dims):
            for j in range(i+1,dims):
                if graph[i,j]==-1 and graph[j,i]==1:
                    graph[i,j]=1
                    graph[j,i]=0
                elif graph[i,j]==1 and graph[j,i]==-1:
                    graph[i,j]=0
                    graph[j,i]=1
                elif graph[i,j]==-1 and graph[j,i]==-1:
                    graph[i,j]=1
                    graph[j,i]=1

        return miss_data,graph,self.iscpdag
    

from imps.imputation_missforest import MissForestImputation
class MFX(BaseMethod):
    def __init__(self):
        self.name_ = "MissFor "
        self.alg  = MissForestImputation();
        self.iscpdag = True

    def run(self,data,mrows=None,graph=None):
        miss_data,graph = None,None
        miss_data       = self.alg.fit_transform(data)
        tdata           = miss_data[mrows,:]
        graph = pc(tdata, 0.05, kci, kernelZ='Polynomial',show_progress=False).G.graph

        dims = graph.shape[1]

        for i in range(dims):
            for j in range(i+1,dims):
                if graph[i,j]==-1 and graph[j,i]==1:
                    graph[i,j]=1
                    graph[j,i]=0
                elif graph[i,j]==1 and graph[j,i]==-1:
                    graph[i,j]=0
                    graph[j,i]=1
                elif graph[i,j]==-1 and graph[j,i]==-1:
                    graph[i,j]=1
                    graph[j,i]=1

        return miss_data,graph,self.iscpdag
