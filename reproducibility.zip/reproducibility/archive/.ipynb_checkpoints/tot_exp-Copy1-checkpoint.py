if __name__ == "__main__":

    from utils import *

    import sys
    import os
    import gc

    from imps.MIRACLE import MIRACLE
    #from imps.imputation_knn import KNNImputer
    from imps.imputation_gain import GainImputation
    #from imps.imputation_missforest import MissForestImputation
    from imps.imputation_mice import MiceImputation
    from imps.imputation_mean import MeanImputation

    from sidica.sidica import SIDICA
    from sidica.perfect_oracle import PerfectOracle
    from sidica.mdl_oracle import MDLOracle
    from sidica.globe_oracle import GLOBEOracle
    from sidica.poly_oracle import PolyOracle


    from sidica.mdl_score import MDLScore
    from sidica.poly_score import PolyScore
    from sidica.globe_score import GLOBEScore


    from experiment_factory import ExperimentFactory

    import networkx as nx

    from acyclic_graph_generator import AcyclicGraphGenerator
    from experiment_handler import Experiment

    np.random.seed(37)

    from causallearn.search.ConstraintBased.PC import pc
    from causallearn.utils.cit import kci
    import os

    def gen_data(nodes=10,mech='gaussian_add',noise=0.4,idx=0,rcount=1000,pre_load=True,viz=False):
        foldname = './data/'+str(rcount)+'/'+mech+'/'+str(nodes)+"_"+str(noise)+"/"
        fname = foldname + 'exp' + str(idx) + '.txt'
        gname = foldname + 'exp' + str(idx) + '_truth.txt'
        vname = './viz/'+mech+'/'+str(nodes)+"_"+str(noise)+"/"+ 'exp' + str(idx) + '/'

        if pre_load:
            data            = load_data(fname)
            graph           = load_graph(gname)
            return fname,data,graph


        ed = np.max([1,np.floor(np.log2(nodes))-1])
        #print("exp: ",ed)
        generator = AcyclicGraphGenerator(mech, npoints=rcount,nodes=nodes,initial_variable_generator=gaussian_cause,noise_coeff=noise,expected_degree=ed, dag_type='erdos')
        dt, G = generator.generate()
        graph = nx.to_numpy_array(G)
        data  = dt.to_numpy().reshape((-1,nodes))
        dims  = graph.shape[1]
        data = standardize(data)

        if not os.path.exists(foldname): os.makedirs(foldname) 
        np.savetxt(fname,  data, delimiter=",")
        np.savetxt(gname, graph, delimiter=",")

        if False and viz:
            if not os.path.exists(vname): os.makedirs(vname) 

            for i in range(dims):
                    for j in range(dims):
                        if graph[i,j]!=0: 
                            print(i," -> ", j)
                        save_fig(data[:,i],data[:,j],vname+str(i)+'_'+str(j)+'.png',)

        return fname,data,graph

    def main():
        rcount          = 1000 if len(sys.argv)<2 else int(sys.argv[1])
        mechs,noises,nodes,mask_probs,source_only,file_count,exp_fname = ExperimentFactory.comp_setup(rcount)

        tot_experiments = len(mechs) * len(noises) * len(nodes) * len(mask_probs) * len(source_only) * file_count
        exp_counter     = 0

        exp_headers     = ['fname','tot','so','nodes','samples','oracle','prob','shd','sid','paid','tp','fp','fn','rmse','ir','predicted','graph']#,'miss_data','fill_data']
        experiment      = Experiment(exp_headers,exp_fname,preload=True)


        #[63,74,77] #these were left idle
        print("Saving to ",exp_fname)
        for node in nodes:
            for mech in mechs:
                for noise in noises:
                    for so in source_only:
                        for idx in range(1,file_count+1):
                            fname,dt,graph  = gen_data(node,mech,noise,idx,rcount,pre_load=True)
                            all_vars        = [vv for vv in range(graph.shape[0])]
                            sources         = np.where(np.sum(graph,axis=0)==0)[0]
                            non_source      = list(set(all_vars) - set(sources)) if so else all_vars
                            ns_dt           = dt[:,non_source]
                            for p in mask_probs:
                                exp_counter+=1
                                if exp_counter <78:continue
                                mask               = np.ones((dt.shape[0],dt.shape[1]))
                                mask[:,non_source] = binary_sampler(1 - p, ns_dt.shape[0], ns_dt.shape[1]) #we will only eliminate non source columns
                                xmis               = dt.copy()                                             #make a data copy
                                xmis[mask == 0]    = np.nan

                                #need the following because MIRACLE crashes otherwise
                                dummy_line         = np.array([np.nan for nn in range(dt.shape[1])])
                                xmis               = np.vstack((xmis,dummy_line)) 

                                dummy_mask         = np.array([0 for nn in range(dt.shape[1])])
                                mask               = np.vstack((mask,dummy_mask)) 

                                #end MIRACLE Adjustment

                                mrows_ids          = np.sum(mask,axis=1)<dt.shape[1]
                                #print(xmis.shape)
                                #print(mask.shape)
                                
                                for alg in methods:
                                    try:
                                        midata,pred     = alg.run(np.copy(xmis))
                                        rmse,ir         = rmse_loss(dt,midata,mask)
                                        shd,sid,paid,tp,fp,fn,ac = calc_ud_stats(pred,graph,False)
                                        exp_res         = [fname,np.sum(graph),so,node,rcount,alg.name_,p,shd,sid,paid,tp,fp,fn,rmse,ir,pred,graph]#,np.copy(xmis),midata]
                                        print(rcount,",",exp_counter,"/",tot_experiments,", ",fname,", Method: ",alg.name_,", prob: ",p," source safe: ",so,", Tot: ",np.sum(graph),", SHD: ",shd,", SID: ",sid,", PAID: ",paid,", TP: ",tp,", FP: ",fp,", FN: ",fn,", RMSE: ",rmse," IR: ",ir)
                                        experiment.add(exp_res)
                                        experiment.save_state()
                                    except Exception as e:
                                        print(rcount,",",exp_counter,"/",tot_experiments,", ",fname," for",alg.name_," failed")
                                        print(e)
                                        gc.collect()  

                                #'''
                                try:
                                    #import ipdb;ipdb.set_trace()
                                    alg             = SIDICA(orc=PerfectOracle(graph),sc=GLOBEScore(cache_result=False))
                                    midata,pred     = alg.fit_transform(np.copy(xmis))
                                    rmse,ir         = rmse_loss(dt,midata,mask)
                                    #upred           = np.array(np.abs(pred) + np.abs(pred).T,dtype=bool)
                                    shd,sid,paid,tp,fp,fn,ac = calc_ud_stats(-1*pred,graph,False)
                                    exp_res         = [fname,np.sum(graph),so,node,rcount,'SIDICAO',p,shd,sid,paid,tp,fp,fn,rmse,ir,pred,graph]#,np.copy(xmis),midata]
                                    print(rcount,",",exp_counter,"/",tot_experiments,", ",fname,", Method: SIDICAO , prob: ",p," source safe: ",so,", Tot: ",np.sum(graph),", SHD: ",shd,", SID: ",sid,", PAID: ",paid,", TP: ",tp,", FP: ",fp,", FN: ",fn,", RMSE: ",rmse," IR: ",ir)
                                    experiment.add(exp_res)
                                    experiment.save_state()
                                except Exception as e:
                                    print(rcount,",",exp_counter,"/",tot_experiments,", ",fname," SIDICAO failed")
                                    print(e)
                                gc.collect()    

                                #'''
                                try:
                                    alg             = SIDICA(orc=GLOBEOracle(),sc=GLOBEScore(cache_result=False))
                                    midata,pred     = alg.fit_transform(np.copy(xmis))
                                    rmse,ir         = rmse_loss(dt,midata,mask)
                                    #upred           = np.array(np.abs(pred) + np.abs(pred).T,dtype=bool)
                                    shd,sid,paid,tp,fp,fn,ac = calc_ud_stats(-1*pred,graph,False)
                                    exp_res         = [fname,np.sum(graph),so,node,rcount,'SIDICAG',p,shd,sid,paid,tp,fp,fn,rmse,ir,pred,graph]#,np.copy(xmis),midata]
                                    print(rcount,",",exp_counter,"/",tot_experiments,", ",fname,", Method: SIDICAG , prob: ",p," source safe: ",so,", Tot: ",np.sum(graph),", SHD: ",shd,", SID: ",sid,", PAID: ",paid,", TP: ",tp,", FP: ",fp,", FN: ",fn,", RMSE: ",rmse," IR: ",ir)
                                    experiment.add(exp_res)
                                    experiment.save_state()
                                except Exception as e:
                                    print(rcount,",",exp_counter,"/",tot_experiments,", ",fname," SIDICAG failed")
                                    print(e)
                                gc.collect()  

                                #'''

                                try:

                                    gain_imp   = GainImputation();
                                    gdata      = gain_imp.fit_transform(np.copy(xmis))
                                    #import ipdb;ipdb.set_trace()
                                    tdata      = gdata[mrows_ids,:]
                                    gain_rmse,gain_ir  = rmse_loss(dt,gdata,mask)
                                    pred = pc(tdata, 0.05, kci, kernelZ='Polynomial',show_progress=False).G.graph
                                    upred           = np.array(np.abs(pred) + np.abs(pred).T,dtype=bool)
                                    shd,sid,paid,tp,fp,fn,ac = calc_ud_stats(pred,graph)
                                    exp_res         = [fname,np.sum(graph),so,node,rcount,'Gain',p,shd,sid,paid,tp,fp,fn,gain_rmse,1,pred,graph]#,np.copy(xmis),gdata]
                                    print(rcount,",",exp_counter,"/",tot_experiments,", ",fname,", Method: GAIN    , prob: ",p," source safe: ",so,", Tot: ",np.sum(graph),", SHD: ",shd,", SID: ",sid,", PAID: ",paid,", TP: ",tp,", FP: ",fp,", FN: ",fn,", RMSE: ",gain_rmse," IR: ",gain_ir)
                                    experiment.add(exp_res)
                                    experiment.save_state()
                                except Exception as e:
                                    print(exp_counter,"/",tot_experiments,", ",fname," GAIN failed")
                                    print(e)

                                gc.collect()
                                #'''
                                #'''    
                                try:
                                    mice_imp  = MiceImputation();
                                    mice_data = mice_imp.fit_transform(np.copy(xmis))
                                    tdata      = mice_data[mrows_ids,:]
                                    mice_rmse,mice_ir = rmse_loss(dt,mice_data,mask)
                                    pred = pc(tdata, 0.05, kci, kernelZ='Polynomial',show_progress=False).G.graph
                                    upred           = np.array(np.abs(pred) + np.abs(pred).T,dtype=bool)
                                    shd,sid,paid,tp,fp,fn,ac = calc_ud_stats(pred,graph)
                                    exp_res         = [fname,np.sum(graph),so,node,rcount,'MICE',p,shd,sid,paid,tp,fp,fn,mice_rmse,1,pred,graph]#np.copy(xmis),mice_data]
                                    print(rcount,",",exp_counter,"/",tot_experiments,", ",fname,", Method: MICE    , prob: ",p," source safe: ",so,", Tot: ",np.sum(graph),", SHD: ",shd,", SID: ",sid,", PAID: ",paid,", TP: ",tp,", FP: ",fp,", FN: ",fn,", RMSE: ",mice_rmse," IR: ",mice_ir )
                                    experiment.add(exp_res)
                                    experiment.save_state()
                                except Exception as e:
                                    print(exp_counter,"/",tot_experiments,", ",fname," MICE failed")
                                    print(e)
                                #'''
                                gc.collect()    
                                try:
                                    mean_imp  = MeanImputation();
                                    mean_data = mean_imp.fit_transform(np.copy(xmis))
                                    tdata      = mean_data[mrows_ids,:]
                                    mean_rmse,mean_ir = rmse_loss(dt,mean_data,mask)
                                    pred = pc(tdata, 0.05, kci, kernelZ='Polynomial',show_progress=False).G.graph
                                    upred           = np.array(np.abs(pred) + np.abs(pred).T,dtype=bool)
                                    shd,sid,paid,tp,fp,fn,ac = calc_ud_stats(pred,graph)
                                    exp_res         = [fname,np.sum(graph),so,node,rcount,'MEAN',p,shd,sid,paid,tp,fp,fn,mean_rmse,1,pred,graph]#np.copy(xmis),mean_data]
                                    print(rcount,",",exp_counter,"/",tot_experiments,", ",fname,", Method: MEAN    , prob: ",p," source safe: ",so,", Tot: ",np.sum(graph),", SHD: ",shd,", SID: ",sid,", PAID: ",paid,", TP: ",tp,", FP: ",fp,", FN: ",fn,", RMSE: ",mean_rmse," IR: ",mean_ir)
                                    experiment.add(exp_res)
                                    experiment.save_state()
                                except Exception as e:
                                    print(exp_counter,"/",tot_experiments,", ",fname," MEAN failed")
                                    print(e)
                                gc.collect()        

                                try:
                                    miracle_imp   = MIRACLE(num_inputs=xmis.shape[1],max_steps=400)
                                    mirdata, pred    = miracle_imp.fit(xmis)
                                    tdata         = mirdata[mrows_ids,:]
                                    miracle_rmse,miracle_ir  = rmse_loss(dt, mirdata, mask)
                                    #pred = np.abs(pc(tdata, 0.05, kci, kernelZ='Polynomial',show_progress=False).G.graph)
                                    upred           = np.array(np.abs(pred) + np.abs(pred).T,dtype=bool)
                                    shd,sid,paid,tp,fp,fn,ac = calc_ud_stats(-1*pred,graph,False)
                                    exp_res         = [fname,np.sum(graph),so,node,rcount,'MIRACLE',p,shd,sid,paid,tp,fp,fn,miracle_rmse,1,pred,graph]#,np.copy(xmis),mirdata]
                                    print(rcount,",",exp_counter,"/",tot_experiments,", ",fname,", Method: MIRACLE , prob: ",p," source safe: ",so,", Tot: ",np.sum(graph),", SHD: ",shd,", SID: ",sid,", PAID: ",paid,", TP: ",tp,", FP: ",fp,", FN: ",fn,", RMSE: ",miracle_rmse," IR: ",miracle_ir)
                                    experiment.add(exp_res)
                                    experiment.save_state()

                                except Exception as e:
                                    print(exp_counter,"/",tot_experiments,", ",fname," MIRACLE failed")
                                    print(e)



                                #'''
                                #experiment.save_state()
                                gc.collect()

                                print('---')


                            #print(fname," -- SHD: ",shd2,", TP: ",tp,"/",np.sum(graph),", FP: ",fp,", FN: ",fn,", Rev: ",ac)#, "Order: ",c_order)
        print("#############")


    main();