import numpy as np
from sidica.node import Node
from sidica.mdl_oracle import MDLOracle
from sidica.mdl_score import MDLScore


from sidica.base_regressors import MeanRegressor, DTRegressor

import itertools
import gc
from ordered_set import OrderedSet
from utils import save_fig_tup

class SIDICA:
    
    def __init__(self,orc=None,sc=None):
        self.is_init = True
        self.oracle = orc if orc is not None else MDLOracle()
        self.score  = sc  if sc  is not None else MDLScore(cache_result=False)

    def fit_transform(self,data,gt=None):
        dims  = data.shape[1]
        rows  = data.shape[0]
        graph = np.eye(dims)*0
        
        clusters = self.determine_clusters(data)
        if gt is None:
            c_order,_  = self.determine_order(clusters,data)
        else:
            c_order,_  = self.determine_perfect_order(gt)
        #print(c_order)
        
        for target in range(1,dims):
            poss_parents = [c_order[i] for i in range(target) if not self.oracle.is_independent(c_order[target],c_order[i],data)]    #get all variables in causal ordering upto this variable, naturally excluding those that were deemed independent.
            parents,scm                  = self.find_parents(c_order[target],poss_parents,data)    #try and do subset selection for this variable given variables before it, return SCM
            graph[parents , c_order[target]]      = 1                                              #set incoming edges from parents to this child
            missing_indexes              = np.argwhere(np.isnan(data[:,c_order[target]])) #get the values for which the target is missing
            if missing_indexes.shape[0]>0:
                data[missing_indexes,target] = scm.predict(data[missing_indexes,parents])     #use the learned parents and SCM to impute missing values for this target

        self.score.reset() 
        gc.collect()
        return data, graph,c_order
    
    def determine_perfect_order(self,graph):
        queue = []
        visited = [False for i in range(graph.shape[1])]
        layer = 1
        sources = np.argwhere(np.sum(graph,axis=0)==0)

        #all sources go in by default as layer 1
        for src in sources:
            queue.append( (src.item(),layer) )

        while len(queue)!=0:
            node, layer = queue.pop(0)
            visited[node] = layer
            children = np.argwhere(graph[node,:]!=0)
            for c in children: queue.append((c.item(),layer+1))

        if False in visited: print("Error in traversal, atleast one node was left unvisited")
        vis = np.array(visited)
        max_ent = np.max(vis)
        order=[]

        for i in range(0,max_ent+1):
            for j in range(graph.shape[1]):
                if visited[j] == i:
                    order.append(j)
        
        return order,[]
    
    
    def determine_clusters(self,data,seed_node=3):
        dims         = data.shape[1]
        node_array   = []
        cluster_list = [] #this will contain a list of connected components of a graph, ideally one per source node.
        self.oracle.init_independence(dims)

        init_cluster = [i for i in range(dims)]        # define first cluster to contain all variables
        #print(seed_node)
        first_cluster,alt_cluster =self.split_cluster(init_cluster,data,seed_node)
        #print(seed_node,": ",first_cluster)
        
        split_cluster, extra_nodes = self.cluster_correction(first_cluster,data) # if we accidentally started at a collider or its child, init cluster will contain two sources. We need to disentangle them.
        cluster_list.append(split_cluster)          
        alt_cluster.extend(extra_nodes)
        #if len(alt_cluster)>0: print("After correction: ",split_cluster," / ",alt_cluster)
        
        finished = len(alt_cluster)==0              #nothing left to do if there are not variables left in the alternate cluster

        while not finished:
            #print("Splitting: ",alt_cluster)
            cluster, _ = self.split_cluster([i for i in range(dims)],data,alt_cluster[0])
            #print(alt_cluster[0],": ",cluster)
            cluster_list.append(cluster)
            
            s1 = set([i for i in range(dims)])
            s2 = set()
            
            for t_cluster in cluster_list:
                s2 = s2.union(set(t_cluster))
            
            finished = s2==s1
            alt_cluster = list(s1 - s2)
            #print("New: ",cluster," / ",alt_cluster)
        return cluster_list
    
    def cluster_correction(self,cluster,data):
        dims = data.shape[1]
        for i in cluster:
            for j in cluster:

                if i!=j and self.oracle.is_independent(i,j,data):
                    #print("Found: ",i," indep. ", j)
                    s1,s2   = i,j            #we found two nodes that are independent, should search for connected components from these
                    c1_full = cluster.copy()
                    c1_full.remove(s2)
                    
                    c2_full = cluster.copy()
                    c2_full.remove(s1)
                    cluster1,_ =self.split_cluster(c1_full,data,c1_full.index(s1))
                    cluster2,_ =self.split_cluster(c2_full,data,c2_full.index(s2))
                    #print(s1,":sp: ",cluster1)
                    #print(s2,":sp: ",cluster2)
                    return [cluster1,cluster2]
                
        return [cluster,[]]
        
    def split_cluster(self,cluster,data,seed_idx=0):
        init_cluster = cluster.copy()
        alt_cluster  = []
        dims = data.shape[1]
        seed_node=cluster[seed_idx]
        
        #print("Splitting on: ",seed_node)
        for i in cluster:
            if i==seed_node: continue
            '''
            if 'Perfect' not in self.oracle.name_:
                chunk = data[:,[i,seed_node]]
                complete_chunk = chunk[~np.isnan(chunk).any(axis=1)]
                s1,_    = self.score.compute(complete_chunk,1,[])
                s1_pa,m12 = self.score.compute(complete_chunk,1,[0])
                s2,_    = self.score.compute(complete_chunk,0,[])
                s2_pa,m21 = self.score.compute(complete_chunk,0,[1])
                #print(i, "->", seed_node,"=== ",s1, " -> ", s1_pa, ' = ',(s1-s1_pa)/complete_chunk.shape[0])
                #print(seed_node, "->", i,"=== ",s2, " -> ", s2_pa, ' = ',(s2-s2_pa)/complete_chunk.shape[0])
                #print("Putting ",i, " in a different cluster from ",seed_node)

                pred_12 = m12.predict(complete_chunk[:,0].reshape(-1,1))
                pred_21 = m21.predict(complete_chunk[:,1].reshape(-1,1))

                tup1 = [(complete_chunk[:,0],pred_12,'r'),(complete_chunk[:,0],complete_chunk[:,1],'y')];tup1.reverse()
                tup2 = [(complete_chunk[:,1],pred_21,'r'),(complete_chunk[:,1],complete_chunk[:,0],'y')];tup2.reverse()

                save_fig_tup(tup1,"./verify/"+str(i)+"_"+str(seed_node)+".png")
                save_fig_tup(tup2,"./verify/"+str(seed_node)+"_"+str(i)+".png")
                    
            #'''  
            
            #if a variable is independent of seed node, put it in a different cluster
            if self.oracle.is_independent(seed_node,i,data):
                '''
                if 'Perfect' not in self.oracle.name_:
                    chunk = data[:,[i,seed_node]]
                    complete_chunk = chunk[~np.isnan(chunk).any(axis=1)]
                    s1,_    = self.score.compute(complete_chunk,1,[])
                    s1_pa,m12 = self.score.compute(complete_chunk,1,[0])
                    s2,_    = self.score.compute(complete_chunk,0,[])
                    s2_pa,m21 = self.score.compute(complete_chunk,0,[1])
                    print(i, "->", seed_node,"=== ",s1, " -> ", s1_pa, ' = ',(s1-s1_pa)/complete_chunk.shape[0])
                    print(seed_node, "->", i,"=== ",s2, " -> ", s2_pa, ' = ',(s2-s2_pa)/complete_chunk.shape[0])
                    print("Putting ",i, " in a different cluster from ",seed_node)

                    pred_12 = m12.predict(complete_chunk[:,0].reshape(-1,1))
                    pred_21 = m21.predict(complete_chunk[:,1].reshape(-1,1))

                    tup1 = [(complete_chunk[:,0],pred_12,'r'),(complete_chunk[:,0],complete_chunk[:,1],'y')];tup1.reverse()
                    tup2 = [(complete_chunk[:,1],pred_21,'r'),(complete_chunk[:,1],complete_chunk[:,0],'y')];tup2.reverse()

                    save_fig_tup(tup1,"./verify/"+str(i)+"_"+str(seed_node)+".png")
                    save_fig_tup(tup2,"./verify/"+str(seed_node)+"_"+str(i)+".png")
                #'''
                alt_cluster.append(i)
                init_cluster.remove(i)

        return init_cluster, alt_cluster
    
    def determine_order(self,clusters,data):
        dims = data.shape[1]
        c_dim = len(clusters)
        simplified_clusters=[]
        
        accumulated = set(clusters[0])
        simplified_clusters.append(clusters[0])
        
        #we are breaking down clusters into sub parts now
        for ci in range(1,c_dim):
            common_nodes   = accumulated.intersection(set(clusters[ci]))
            ancestor_nodes = list(set(clusters[ci]) - common_nodes)
            simplified_clusters.append(ancestor_nodes)
            accumulated    = accumulated.union(set(clusters[ci]))

            
        #now we order clusters independently
        final_order=[]
        for sc in simplified_clusters:
            if len(sc)==1: continue
            ordered_sc = self.determine_intra_cluster_order(sc.copy(),data)
            final_order.append(ordered_sc)

        #individual clusters have been ordered within themselves
        #next we merge the sorted clusters into a single list of valid (local) causal order
        for sc in simplified_clusters:
            if len(sc)==1: 
                final_order.append(sc.copy())
        
        final_order.reverse()
        flat_list=[]
        for l in final_order:
            flat_list.extend(l)
        return flat_list,final_order

    def determine_intra_cluster_order(self,cluster,data):
        dims = data.shape[1]
        c_dim = len(cluster)
        if c_dim==1: return cluster
        node_array=[]
        for i in range(dims):
            node_array.append(Node(i,dims))
        
        for ci in range(c_dim):
            i=cluster[ci]
            for cj in range(ci+1,c_dim):
                j=cluster[cj]
                chunk = data[:,[i,j]]
                complete_chunk = chunk[~np.isnan(chunk).any(axis=1)]
        
                #in completed chunk, i will be 0th index and j will always be 1st index
                delta_ij = self.score.compute_gain(complete_chunk,1,[],0)  #what is the gain in bits when explaining j using edge i -> j ?
                delta_ji = self.score.compute_gain(complete_chunk,0,[],1)
                
                node_array[i].comps[j] = 1 if delta_ij > delta_ji else 0
                node_array[j].comps[i] = 1 if delta_ji > delta_ij else 0


        for i in range(dims-1,-1,-1):
            if i not in cluster:
                del node_array[i]

        node_array.sort()
        mod  = [n.id for n in node_array]
        return mod
    
    def find_parents(self,child,poss_pa,data):
        #print("Choosing for ",child)
        converged = True
        dims = data.shape[1]
        edge_removed = True;

        #import ipdb;ipdb.set_trace()
        while edge_removed:
            edge_removed  = False;
            curr_parents  = poss_pa
            
            #find ids that are complete
            idxs             = poss_pa.copy()
            tpx=poss_pa.copy()
            idxs.append(child)
            mod_data         = self.get_non_missing_rows(data,idxs)
            mod_curr_parents = [pid for pid in range(len(curr_parents))]
            mod_child        = len(idxs)-1

            #print("Size: ",mod_data.shape)
            s_full,c_model    = self.score.compute_normalized(mod_data,mod_child,mod_curr_parents)
            #print(tpx," -> ",child," = " , s_full)

            set_size      = len(curr_parents) - 1
            if set_size < 0: break
            sets          = itertools.combinations(mod_curr_parents,set_size)
            
            for set_ in sets:
                trunc_idxs = [curr_parents[ss] for ss in list(set_)]           #for this set, get back the actual indexes
                trpx = trunc_idxs.copy()
                trunc_idxs.append(child)                                       #add child to the list
                trunc_mod_data = self.get_non_missing_rows(data,trunc_idxs)    #get data for which child and this truncated parent-set is not Nan.
                trunc_mod_curr_parents = [ti for ti in range(len(list(set_)))]
                trunc_mod_child = len(trunc_idxs)-1
                s_trunc,s_scm = self.score.compute_normalized(trunc_mod_data,trunc_mod_child,trunc_mod_curr_parents );
                #print(trpx," -> ",child," = " , s_trunc)
                
                if s_full > s_trunc-int(not edge_removed)*0.01: #only check for no-hypercompressibility if the full_set is still in its original form
                    edge_removed   = True
                    s_full         = s_trunc
                    best_s         = set_
                    best_scm       = s_scm
                    

            if edge_removed:
                master_set         = set(mod_curr_parents);
                sub_set            = set(best_s);
                removed_index      = list(master_set - sub_set)[0];
                poss_pa            = [curr_parents[ss] for ss in sub_set]
                converged          = False
                c_model            = best_scm

        #print(poss_pa," returned")
        #import ipdb;ipdb.set_trace()
        return poss_pa,c_model
    
    
    def get_non_missing_rows(self,data,idxs):
        chunk            = data[:,idxs]
        mod_data         = chunk[~np.isnan(chunk).any(axis=1)]
        return mod_data
    
    