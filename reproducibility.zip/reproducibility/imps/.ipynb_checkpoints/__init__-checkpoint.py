# stdlib
from typing import Any

import sys
import tensorflow as tf
print("GPU Available at start:", tf.config.list_physical_devices('GPU'))
from . import logger  # noqa: F401
from .MIRACLE import MIRACLE  # noqa: F401

logger.add(sink=sys.stderr, level="CRITICAL")
