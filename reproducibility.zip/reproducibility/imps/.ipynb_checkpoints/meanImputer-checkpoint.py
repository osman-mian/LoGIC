import numpy as np
from scm import SCM

class meanImputer():
    
    def __init__(self):
        is_init=True
        
        
    def impute(self,data):
        mu_  = np.nanmean(data,axis=0)
        dims = data.shape[1]
        mod  = SCM()

        for i in range(dims):
            idx = np.where(np.isnan(data[:,i]))
            data[idx,i]=mu_[i]
            
        mod.graph = np.eye(dims)
        mod.eq_list=[]
        
        return data,mod